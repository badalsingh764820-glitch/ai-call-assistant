# AI Call Assistant (Android)

Aapke liye banaya gaya starter Android app jo incoming calls ko AI se attend karta hai.

## Kya karta hai
- Incoming call par AI voice se jawab deta hai (Hindi + English)
- **Gemini se natural baat-cheet**: caller ka naam puchta hai, kaam samajhta hai, 8 turn tak baat karta hai
- Call ka AI-generated summary app me save karta hai (naam + kaam)
- Spam jaisi calls ko alag mark karta hai
- API key na ho to simple rule-based mode me kaam karta hai

## Gemini API key kaise layein (free)
1. https://aistudio.google.com kholo aur Google account se login karo
2. "Get API Key" > "Create API Key" dabao
3. Key copy karke app me **API key** wale box me paste karo aur Save dabao
4. Bas! Ab calls par smart AI baat karega.

## Important note (Android limits)
- Call ko khud se uthane ke liye app ko **Default Phone App** banana padta hai (Android 10+ ka rule hai)
- Play Store par dalne se pehle CALL_SCREENING / dialer permissions ka declaration chahiye
- Ye starter code hai — isme AI brain abhi simple rule-based hai. Chaaho to isme Gemini / OpenAI API jod sakte ho.

## Bina Android Studio ke APK kaise lo (free cloud build)
Mere paas yahan APK banane ka setup nahi hai, isliye GitHub ka free build laga diya hai:

1. https://github.com par free account banao
2. New repository banao (naam: `ai-call-assistant`)
3. Is zip ki saari files us repo me upload karo (Add file > Upload files)
4. Repo ke **Actions** tab me jao — "Build APK" workflow khud chal jayega
5. Build poora hone par neeche **Artifacts** me `ai-call-assistant-apk` milega — download karo
6. APK ko phone me copy karke install karo (Unknown sources allow karna padega)

## Android Studio se chalana (optional)
1. Android Studio me `ai-call-assistant` folder kholo
2. Gradle sync karo
3. Phone par install karo
4. Settings > Apps > Default apps > Phone app me **AI Call Assistant** select karo
5. App kholo, "AI Assistant ON" rakho

## Structure
- `AICallScreeningService.kt` — incoming call detect + screening
- `AIVoiceAssistant.kt` — TTS/STT se baat karne wala AI flow
- `MainActivity.kt` — ON/OFF, call summaries ki list
