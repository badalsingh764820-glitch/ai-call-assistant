package com.llxscopion.aicallassistant

/** Demo spam rules — baad me Truecaller-type API ya ML se replace karo */
object SpamChecker {
    private val spamPrefixes = listOf("140", "1800-1", "+140")

    fun isSpam(number: String): Boolean {
        val digits = number.filter { it.isDigit() }
        if (digits.length < 7) return true
        if (spamPrefixes.any { number.startsWith(it) }) return true
        // Repeated digits jaisa simple pattern
        if (digits.toSet().size <= 2 && digits.length >= 10) return true
        return false
    }
}
