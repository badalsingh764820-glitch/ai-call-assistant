package com.llxscopion.aicallassistant

import android.content.Context
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.Call
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * AI voice flow: Gemini se natural baat karke naam + kaam nikalta hai.
 * API key na ho to purana rule-based flow fallback me chalta hai.
 */
object AIVoiceAssistant {

    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Ek waqt me ek hi call handle karo
    @Volatile private var busy = false

    fun handleIncomingCall(context: Context, number: String, callDetails: Call.Details) {
        if (busy) return
        busy = true
        val appContext = context.applicationContext
        val apiKey = GeminiBrain.getApiKey(appContext)

        if (apiKey.isBlank()) {
            oldRuleBasedFlow(appContext, number) { busy = false }
        } else {
            geminiConversation(appContext, number, apiKey) { busy = false }
        }
    }

    // ---------- Gemini wali smart baat-cheet ----------

    private fun geminiConversation(
        context: Context,
        number: String,
        apiKey: String,
        onDone: () -> Unit
    ) {
        val history = mutableListOf<GeminiBrain.Msg>()
        val transcript = StringBuilder()
        var turns = 0
        val maxTurns = 8

        fun finish() {
            // Summary banao aur save karo
            scope.launch(Dispatchers.IO) {
                val (name, purpose) = GeminiBrain.summarize(apiKey, transcript.toString())
                CallRepository.addSummary(
                    context,
                    CallSummary(
                        number = number,
                        time = System.currentTimeMillis(),
                        callerName = name,
                        purpose = purpose,
                        isSpam = false
                    )
                )
                scope.launch(Dispatchers.Main) { onDone() }
            }
        }

        fun aiTurn() {
            if (turns >= maxTurns) {
                speak(context, "Dhanyavaad! Aapka sandesh note kar liya hai. Namaste!") { finish() }
                return
            }
            scope.launch {
                val reply = GeminiBrain.nextReply(apiKey, history.toList())
                if (reply.isBlank()) {
                    // API fail: purane flow par gir jao
                    speak(context, "Maaf kijiye, network me dikkat hai. Kripya apna naam aur kaam bata dein.") {
                        listenOnce(context) { heard ->
                            transcript.append("Caller: ").append(heard).append("\n")
                            CallRepository.addSummary(
                                context,
                                CallSummary(
                                    number, System.currentTimeMillis(),
                                    null,
                                    heard.ifBlank { "API fail — maksad clear nahi" }, false
                                )
                            )
                            speak(context, "Dhanyavaad! Namaste!") { onDone() }
                        }
                    }
                    return@launch
                }

                val clean = reply.replace("[END]", "").trim()
                val shouldEnd = reply.contains("[END]") || turns >= maxTurns - 1
                history.add(GeminiBrain.Msg("model", clean))
                transcript.append("AI: ").append(clean).append("\n")

                speak(context, clean) {
                    if (shouldEnd) {
                        finish()
                    } else {
                        listenOnce(context) { heard ->
                            if (heard.isBlank()) {
                                turns++
                                aiTurn() // kuch sunai nahi diya, AI dobara bolega
                            } else {
                                turns++
                                history.add(GeminiBrain.Msg("user", heard))
                                transcript.append("Caller: ").append(heard).append("\n")
                                aiTurn()
                            }
                        }
                    }
                }
            }
        }

        // Pehla AI message
        scope.launch {
            val first = GeminiBrain.nextReply(
                apiKey,
                listOf(GeminiBrain.Msg("user", "(Nayi incoming call aayi hai. Caller ko greet karo aur naam pucho.)"))
            ).replace("[END]", "").trim()
                .ifBlank { "Namaste! Main LLXSCOPION ka AI assistant bol raha hoon. Kripya apna naam batayein." }

            history.add(GeminiBrain.Msg("model", first))
            transcript.append("AI: ").append(first).append("\n")
            speak(context, first) {
                listenOnce(context) { heard ->
                    if (heard.isNotBlank()) {
                        turns++
                        history.add(GeminiBrain.Msg("user", heard))
                        transcript.append("Caller: ").append(heard).append("\n")
                    }
                    aiTurn()
                }
            }
        }
    }

    // ---------- Purana simple flow (API key na ho tab) ----------

    private fun oldRuleBasedFlow(context: Context, number: String, onDone: () -> Unit) {
        speak(
            context,
            "Namaste! Main LLXSCOPION ka AI assistant bol raha hoon. " +
                "Kripya apna naam aur aapne kis kaam se call kiya hai, batayein. " +
                "(Note: smart jawab ke liye app me Gemini API key dalein.)"
        ) {
            listenOnce(context) { heard ->
                CallRepository.addSummary(
                    context,
                    CallSummary(
                        number = number,
                        time = System.currentTimeMillis(),
                        callerName = null,
                        purpose = heard.ifBlank { "Purpose clear nahi hua" },
                        isSpam = false
                    )
                )
                speak(context, "Dhanyavaad! Aapka sandesh note kar liya hai. Namaste!") { onDone() }
            }
        }
    }

    // ---------- TTS / STT helpers ----------

    private fun ensureTts(context: Context, onReady: () -> Unit) {
        val existing = tts
        if (existing != null) {
            onReady()
            return
        }
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
            onReady()
        }
    }

    private fun speak(context: Context, text: String, onDone: () -> Unit) {
        ensureTts(context) {
            val engine = tts
            if (engine == null) {
                onDone()
                return@ensureTts
            }
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) { onDone() }
                override fun onDone(utteranceId: String?) { onDone() }
            })
            engine.language = Locale("hi", "IN")
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ai_${System.currentTimeMillis()}")
        }
    }

    private fun listenOnce(context: Context, onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onResult("")
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
        }
        var done = false
        fun finishOnce(result: String) {
            if (done) return
            done = true
            try { recognizer.destroy() } catch (_: Exception) {}
            onResult(result)
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                finishOnce(list?.firstOrNull().orEmpty())
            }
            override fun onError(error: Int) { finishOnce("") }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        try {
            recognizer.startListening(intent)
        } catch (_: Exception) {
            finishOnce("")
        }
        // Safety timeout: 20 sec me kuch na sunai de to aage badho
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ finishOnce("") }, 20000)
    }

    fun shutdown() {
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        busy = false
    }
}
