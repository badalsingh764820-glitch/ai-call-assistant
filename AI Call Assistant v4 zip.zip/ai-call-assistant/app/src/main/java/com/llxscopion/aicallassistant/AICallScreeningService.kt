package com.llxscopion.aicallassistant

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService

/**
 * Incoming call ko detect karke AI flow start karta hai.
 * Note: call ko audio me jawab dene ke liye app ko Default Dialer
 * banana hoga. Ye service screening + info deti hai.
 */
class AICallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val prefs = getSharedPreferences("ai_prefs", MODE_PRIVATE)
        val enabled = prefs.getBoolean("ai_enabled", true)
        val number = callDetails.handle?.schemeSpecificPart ?: "Unknown"

        val response = CallResponse.Builder()
        if (!enabled) {
            // AI off hai to normal rehne do
            respondToCall(callDetails, response.build())
            return
        }

        // Spam check (simple demo rule)
        val isSpam = SpamChecker.isSpam(number)

        if (isSpam) {
            // Spam ko silent reject
            val spamResponse = CallResponse.Builder()
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
            CallRepository.addSummary(
                this,
                CallSummary(
                    number = number,
                    time = System.currentTimeMillis(),
                    callerName = null,
                    purpose = "Spam call — auto rejected",
                    isSpam = true
                )
            )
            respondToCall(callDetails, spamResponse)
        } else {
            // Normal call: AI voice assistant ko trigger karo
            // (Default dialer banne par yahan Telecom Call ko answer karke
            //  AIVoiceAssistant.startConversation() chalega)
            AIVoiceAssistant.handleIncomingCall(this, number, callDetails)

            val allow = CallResponse.Builder()
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
            respondToCall(callDetails, allow)
        }
    }
}
