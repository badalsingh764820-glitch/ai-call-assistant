package com.llxscopion.aicallassistant

data class CallSummary(
    val number: String,
    val time: Long,
    val callerName: String?,
    val purpose: String,
    val isSpam: Boolean
)
