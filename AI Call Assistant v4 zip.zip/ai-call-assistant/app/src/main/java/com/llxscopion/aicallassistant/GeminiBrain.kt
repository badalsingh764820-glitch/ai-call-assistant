package com.llxscopion.aicallassistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini API se natural baat karne wala AI brain.
 * API key: https://aistudio.google.com se free me milti hai,
 * app ki settings me ek baar dalni hai.
 */
object GeminiBrain {

    // Zaroorat pade to model ka naam yahan badal sakte ho
    private const val MODEL = "gemini-2.0-flash"

    data class Msg(val role: String, val text: String) // role: "user" | "model"

    private const val SYSTEM_PROMPT = """
Tum LLXSCOPION ke personal AI call assistant ho. Tum incoming phone call attend kar rahe ho.
Niyam:
- Hamesha Hindi (Roman Hindi / Hinglish) me baat karo, jaise "Namaste! Main LLXSCOPION ka AI assistant bol raha hoon."
- Pehle caller ka naam pucho, phir pucho ki unhone kis kaam se call kiya.
- Vinamra, chhota aur natural jawab do — ek baar me 1-2 line se zyada mat bolo.
- Agar caller spam/loan/offer bechne wala lage to politely mana karke call khatm karo.
- Agar caller "bye", "rakh", "khatm" bole to dhanyavaad kehke baat khatm karo aur jawab me [END] likh do.
- Kabhi ye mat batao ki tum ek language model ho; tum bas "AI assistant" ho.
"""

    /**
     * Poori conversation history bhejke Gemini se agla jawab lao.
     * Khali string aaye to samjho API fail hui.
     */
    suspend fun nextReply(apiKey: String, history: List<Msg>): String =
        withContext(Dispatchers.IO) {
            try {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = 20000
                    readTimeout = 20000
                    doOutput = true
                }

                val contents = JSONArray()
                // System prompt pehle user message ki tarah
                contents.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
                })
                contents.put(JSONObject().apply {
                    put("role", "model")
                    put("parts", JSONArray().put(JSONObject().put("text", "Samajh gaya. Main LLXSCOPION ka AI assistant hoon aur caller se Hindi me vinamrata se baat karunga.")))
                })
                history.forEach { m ->
                    contents.put(JSONObject().apply {
                        put("role", m.role)
                        put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                    })
                }

                val body = JSONObject().apply {
                    put("contents", contents)
                    put("generationConfig", JSONObject().apply {
                        put("maxOutputTokens", 150)
                        put("temperature", 0.7)
                    })
                }

                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream.bufferedReader().readText()
                conn.disconnect()

                if (code !in 200..299) return@withContext ""

                val text = JSONObject(resp)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                text.trim()
            } catch (e: Exception) {
                ""
            }
        }

    /**
     * Poori baat-cheet ka 2-line summary banao (app me dikhane ke liye).
     */
    suspend fun summarize(apiKey: String, transcript: String): Pair<String?, String> =
        withContext(Dispatchers.IO) {
            try {
                val prompt = """
Neeche ek phone call ki baat-cheet hai. Iska jawab is format me do:
Naam: <caller ka naam ya "Pata nahi">
Kaam: <1 line me call ka maksad>

Baat-cheet:
$transcript
""".trimIndent()
                val reply = nextReplyRaw(apiKey, prompt)
                if (reply.isBlank()) return@withContext Pair(null, transcript.take(200))

                var name: String? = null
                var purpose = ""
                reply.lines().forEach { line ->
                    val l = line.trim()
                    when {
                        l.startsWith("Naam:", ignoreCase = true) ->
                            name = l.substringAfter(":").trim().takeIf { it.isNotBlank() && !it.contains("pata nahi", true) }
                        l.startsWith("Kaam:", ignoreCase = true) ->
                            purpose = l.substringAfter(":").trim()
                    }
                }
                Pair(name, purpose.ifBlank { "Baat-cheet ka maksad clear nahi hua" })
            } catch (e: Exception) {
                Pair(null, transcript.take(200))
            }
        }

    private suspend fun nextReplyRaw(apiKey: String, prompt: String): String =
        withContext(Dispatchers.IO) {
            try {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = 20000
                    readTimeout = 20000
                    doOutput = true
                }
                val body = JSONObject().apply {
                    put("contents", JSONArray().put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    }))
                    put("generationConfig", JSONObject().apply {
                        put("maxOutputTokens", 200)
                        put("temperature", 0.3)
                    })
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream.bufferedReader().readText()
                conn.disconnect()
                if (code !in 200..299) return@withContext ""
                JSONObject(resp)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text").trim()
            } catch (e: Exception) {
                ""
            }
        }

    fun getApiKey(context: android.content.Context): String =
        context.getSharedPreferences("ai_prefs", android.content.Context.MODE_PRIVATE)
            .getString("gemini_api_key", "").orEmpty()

    fun saveApiKey(context: android.content.Context, key: String) {
        context.getSharedPreferences("ai_prefs", android.content.Context.MODE_PRIVATE)
            .edit().putString("gemini_api_key", key.trim()).apply()
    }
}
