package com.llxscopion.aicallassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var toggle: Switch
    private lateinit var statusText: TextView
    private lateinit var list: RecyclerView
    private lateinit var clearBtn: Button
    private lateinit var apiKeyInput: EditText
    private lateinit var saveKeyBtn: Button
    private lateinit var aiModeText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toggle = findViewById(R.id.aiToggle)
        statusText = findViewById(R.id.statusText)
        list = findViewById(R.id.summaryList)
        clearBtn = findViewById(R.id.clearBtn)
        apiKeyInput = findViewById(R.id.apiKeyInput)
        saveKeyBtn = findViewById(R.id.saveKeyBtn)
        aiModeText = findViewById(R.id.aiModeText)

        list.layoutManager = LinearLayoutManager(this)

        val prefs = getSharedPreferences("ai_prefs", MODE_PRIVATE)
        toggle.isChecked = prefs.getBoolean("ai_enabled", true)
        toggle.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("ai_enabled", checked).apply()
            updateStatus(checked)
        }

        apiKeyInput.setText(GeminiBrain.getApiKey(this))
        saveKeyBtn.setOnClickListener {
            val key = apiKeyInput.text.toString().trim()
            GeminiBrain.saveApiKey(this, key)
            updateAiMode()
            Toast.makeText(
                this,
                if (key.isBlank()) "API key hatayi gayi — simple mode chalega"
                else "API key save ho gayi — smart AI mode ON",
                Toast.LENGTH_SHORT
            ).show()
        }

        updateStatus(toggle.isChecked)
        updateAiMode()

        clearBtn.setOnClickListener {
            CallRepository.clear(this)
            refreshList()
            Toast.makeText(this, "History clear ho gayi", Toast.LENGTH_SHORT).show()
        }

        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        updateAiMode()
    }

    private fun updateStatus(enabled: Boolean) {
        statusText.text = if (enabled)
            "AI Assistant ON hai — incoming calls par AI jawab dega."
        else
            "AI Assistant OFF hai — calls normal aayengi."
    }

    private fun updateAiMode() {
        val hasKey = GeminiBrain.getApiKey(this).isNotBlank()
        aiModeText.text = if (hasKey)
            "Smart AI mode: Gemini se natural baat-cheet hogi."
        else
            "Simple mode: API key dalne par Gemini se smart baat hogi. Key: aistudio.google.com se free me leo."
    }

    private fun refreshList() {
        val items = CallRepository.getAll(this)
        list.adapter = SummaryAdapter(items)
    }

    private fun askPermissions() {
        val perms = arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.RECORD_AUDIO
        )
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }
}

class SummaryAdapter(private val items: List<CallSummary>) :
    RecyclerView.Adapter<SummaryAdapter.VH>() {

    class VH(val view: TextView) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply {
            setPadding(24, 24, 24, 24)
            textSize = 15f
        }
        return VH(tv)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val date = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
            .format(Date(s.time))
        val spam = if (s.isSpam) " [SPAM]" else ""
        holder.view.text = "$date$spam\n${s.number} — ${s.callerName ?: "Naam nahi mila"}\nKaam: ${s.purpose}"
    }
}
