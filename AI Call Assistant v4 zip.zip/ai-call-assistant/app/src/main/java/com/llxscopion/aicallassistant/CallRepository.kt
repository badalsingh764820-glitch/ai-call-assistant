package com.llxscopion.aicallassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Call summaries ko SharedPreferences me JSON ki tarah save karta hai (demo storage) */
object CallRepository {
    private const val PREFS = "ai_call_summaries"
    private const val KEY = "summaries"

    fun addSummary(context: Context, summary: CallSummary) {
        val list = getAll(context).toMutableList()
        list.add(0, summary)
        saveAll(context, list.take(100))
    }

    fun getAll(context: Context): List<CallSummary> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        return (0 until arr.length()).map { i ->
            val o: JSONObject = arr.getJSONObject(i)
            CallSummary(
                number = o.optString("number"),
                time = o.optLong("time"),
                callerName = o.optString("callerName").ifBlank { null },
                purpose = o.optString("purpose"),
                isSpam = o.optBoolean("isSpam")
            )
        }
    }

    private fun saveAll(context: Context, list: List<CallSummary>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("number", it.number)
                put("time", it.time)
                put("callerName", it.callerName ?: "")
                put("purpose", it.purpose)
                put("isSpam", it.isSpam)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
